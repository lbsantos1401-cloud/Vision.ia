BELLADONNA — PROTÓTIPO VISUAL

Arquivos:
- index.html: estrutura da página
- style.css: identidade visual e layout responsivo
- script.js: interações demonstrativas

Como publicar no GitHub Pages:
1. Crie um repositório público no GitHub.
2. Envie os três arquivos para a raiz do repositório.
3. Abra Settings > Pages.
4. Em Build and deployment, escolha Deploy from a branch.
5. Selecione a branch main e a pasta /(root), depois salve.
6. Aguarde a publicação e abra o endereço informado pelo GitHub.

Observações:
- Este é um protótipo de apresentação, não uma loja operacional.
- Carrinho, favoritos, busca e newsletter são demonstrações locais.
- Não há pagamento, cadastro real, banco de dados ou integração com fornecedores.
- As fotos são carregadas de URLs externas do Unsplash; é necessária conexão com a internet.
