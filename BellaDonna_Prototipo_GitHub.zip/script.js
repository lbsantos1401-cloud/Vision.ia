const cartCount = document.getElementById("cartCount");
const toast = document.getElementById("toast");
let cartItems = 0;
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

// Demonstração visual: adiciona o item ao contador, sem realizar uma compra.
document.querySelectorAll(".buy-button").forEach((button) => {
  button.addEventListener("click", () => {
    cartItems += 1;
    cartCount.textContent = cartItems;
    showToast("Produto adicionado ao carrinho (demonstração).");
  });
});

document.querySelectorAll(".favorite").forEach((button) => {
  button.addEventListener("click", () => {
    button.classList.toggle("active");
    button.textContent = button.classList.contains("active") ? "♥" : "♡";
  });
});

document.getElementById("searchForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const term = document.getElementById("searchInput").value.trim().toLocaleLowerCase("pt-BR");
  let visible = 0;
  document.querySelectorAll(".product-card").forEach((card) => {
    const match = card.dataset.name.toLocaleLowerCase("pt-BR").includes(term);
    card.hidden = Boolean(term) && !match;
    if (!card.hidden) visible += 1;
  });
  document.getElementById("emptyMessage").hidden = visible !== 0;
});

document.getElementById("newsletterForm").addEventListener("submit", (event) => {
  event.preventDefault();
  showToast("Cadastro demonstrativo realizado. Obrigado!");
  event.target.reset();
});